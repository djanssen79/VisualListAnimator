public class SelectionSortDemo {

    private List<Integer> l;
    VisualListAnimator v = new VisualListAnimator(); 

    public SelectionSortDemo() {
        l = new List<Integer>();
        for (int i=0; i<10; i++) {
            l.append((int)(Math.random()*100));
        }
        v.addList(l, "l");
        selectionSort();        
    }

    public void selectionSort() {
        List<Integer> tmp = new List<Integer>();                            v.addList(tmp, "tmp");

        while (!l.isEmpty()) {
            l.toFirst();                                                    v.animate("TOFIRST", "Zum ersten Element der Liste <l> gehen");
            int min = Integer.MAX_VALUE;
            while (l.hasAccess()) { 
                if (l.getContent() < min) {                                 v.animate("GETCONTENT", "Wenn das aktuelle Element kleiner als das bisherige <min>-Element ist...");
                    min = l.getContent();                                   v.animate("MARK", "... das aktuelle Element als <min>-Element speichern");
                }
                l.next();                                                   v.animate("NEXT", "Zum nächsten Element der Liste <l> gehen");
            }
            l.toFirst();                                                    v.animate("TOFIRST", "Zum ersten Element der Liste <l> gehen");
            while ((l.hasAccess() == true) && (l.getContent() != min)) {    v.animate("GETCONTENT", "Zum <min>-Element der Liste <l> gehen");       
                l.next();                                                   v.animate("NEXT", null);
            }
            tmp.append(l.getContent());                                     v.animate(tmp, "APPEND", "Aktuelles <min>-Element aus <l> an die Liste <tmp> anhängen");
                                                                            v.animate("UNMARK", null);
            l.remove();                                                     v.animate("REMOVE", "Aktuelles <min>-Element aus der Liste <l> entfernen");                                                                            
        }
        l = tmp; 
    }       

}
