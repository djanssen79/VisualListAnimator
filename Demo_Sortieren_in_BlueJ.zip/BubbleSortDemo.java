public class BubbleSortDemo {

    private List<Integer> l;
    private VisualListAnimator<Integer> v = new VisualListAnimator<Integer>();

    public BubbleSortDemo() {
        l = new List<Integer>(); 
        for (int i=0; i<10; i++) {
            l.append((int)(Math.random()*100));            
        }
        v.addList(l, "l");
        bubbleSort();
    }

    private void swapWithPrevious(Integer links, Integer rechts) {        
        l.toFirst();                                                    v.animate(l, "TOFIRST", "Zum ersten Element der Liste <l> gehen");
        while (l.hasAccess()) {
            Integer akt = l.getContent();                               v.animate(l, "GETCONTENT", "Überprüfe, ob das Element das gemerkte Element <links> ist");          
            if (akt == links) {                
                l.setContent(rechts);                                   v.animate(l, "SETCONTENT", "Setze das Element <rechts> hier ein");          
                l.next();                                               v.animate(l, "NEXT", "Zum nächsten Element der Liste <l> gehen");
                l.setContent(links);                                    v.animate(l, "SETCONTENT", "Setze das Element <links> hier ein");
                                                                        v.animate(l, "UNMARK", null);
                return;
            }
            l.next();                                                   v.animate(l, "NEXT", "Zum nächsten Element der Liste <l> gehen");          
        }        
    }

    public void bubbleSort() {
        int n = 0;
        l.toFirst();                                                    v.animate(l, "TOFIRST", "Zum ersten Element der Liste <l> gehen");
        while (l.hasAccess()) {
            l.next();                                                   v.animate(l, "NEXT", "Zum nächsten Element der Liste <l> gehen");
            n++;
        }

        Integer davor = null;        
        for (int i=0; i<n; i++) {
            l.toFirst();                                                v.animate(l, "TOFIRST", "Zum ersten Element der Liste <l> gehen");
            while (l.hasAccess()) {
                davor = l.getContent();                                 v.animate(l, "GETCONTENT", null);
                                                                        v.animate(l, "MARK", "Das zuletzt besuchte Element als <links> merken");
                l.next();                                               v.animate(l, "NEXT", "Zum nächsten Element der Liste <l> gehen");
                if (l.hasAccess() && davor > l.getContent()) {          
                                                                        v.animate(l, "GETCONTENT", "Tausche die beiden Elemente <links> und <rechts>");
                    swapWithPrevious(davor, l.getContent());
                }
            }
        }
    }
}
