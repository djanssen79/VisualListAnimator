public class InsertionSortDemo {

    private List<Integer> l; 
    VisualListAnimator<Integer> v = new VisualListAnimator<Integer>();

    public InsertionSortDemo() {
        l = new List<Integer>(); 
        for (int i=0; i<10; i++) {
            l.append((int)(Math.random()*100));            
        }
        v.addList(l, "l");
        insertionSort();
    }

    public void insertionSort() {
        List<Integer> tmp = new List<Integer>();                        v.addList(tmp, "tmp");

        while (!l.isEmpty()) {
            l.toFirst();                                                v.animate(l, "TOFIRST", "Zum ersten Element der Liste <l> gehen");
            int akt = l.getContent();                                   v.animate(l, "GETCONTENT", "Das aktuelle Element als <akt> merken");                                                                        
            tmp.toFirst();                                              v.animate(tmp, "TOFIRST", "Zum ersten Element der Liste <tmp> gehen");
            while (tmp.hasAccess() && tmp.getContent() < akt) {
                                                                        v.animate(tmp, "GETCONTENT", "Solange das aktuelle Element kleiner als <akt> ist...");
                tmp.next();                                             v.animate(tmp, "NEXT", "...in der Liste <tmp> weitergehen");
            }
            if (tmp.hasAccess()) {
                tmp.insert(akt);                                        v.animate(tmp, "INSERT", "In die Liste <tmp> das <akt>-Element einfügen");
            }
            else {
                tmp.append(akt);                                        v.animate(tmp, "APPEND", "An die Liste <tmp> das <akt>-Element anhängen");
            }
            l.remove();                                                 v.animate(l, "REMOVE", "Das erste Element der Liste <l> löschen");
        }
        l = tmp;        
    }
}
