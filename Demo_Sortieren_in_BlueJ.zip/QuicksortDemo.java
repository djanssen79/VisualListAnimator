public class QuicksortDemo {
    
    private List<Integer> l;
    private VisualListAnimator v = new VisualListAnimator();

    public QuicksortDemo() {
        l = new List<Integer>();
        for (int i=0; i<10; i++) {
            l.append((int)(Math.random()*100));
        }
        v.addList(l, "l");
        quickSort(l);        
    }
    
    public int laenge(List<Integer> liste) {
       int tmp=0;
       liste.toFirst();
       while(liste.hasAccess())
       {
           liste.next();
           tmp++;
        }
        return tmp;
    }
    
    public void quickSort(List<Integer> liste) {
        if (laenge(liste) > 1) {
                                                                v.addList(liste, "liste");
            List<Integer> kleiner = new List<Integer>();        v.addList(kleiner, "kleiner");
            List<Integer> groesser = new List<Integer>();       v.addList(groesser, "groesser");
            liste.toFirst();                                    v.animate(liste, "TOFIRST", "Zum ersten Element der Liste <liste>");
            int pivot = liste.getContent();                     v.animate(liste, "GETCONTENT", "Das Pivot-Element auswählen und als <pivot> zwischenspeichern...");
            liste.remove();                                     v.animate(liste, "REMOVE", "...und aus der Liste <liste> entfernen");
            while(!liste.isEmpty())             
            {
                int tmp = liste.getContent();                   v.animate(liste, "GETCONTENT", "Das aktuelle Element mit dem Pivot-Element vergleichen...");
                if (tmp < pivot)
                {
                    kleiner.append(tmp);                        v.animate(kleiner, "APPEND", "...und zur Liste <kleiner> hinzufügen");
                }
                else
                {
                    groesser.append(tmp);                       v.animate(groesser, "APPEND", "...und zur Liste <groesser> hinzufügen");
                }
                liste.remove();                                 v.animate(liste, "REMOVE", "Aktuelles Element aus der Liste <liste> entfernen");
            }
            quickSort(kleiner);
            quickSort(groesser);
            liste.concat(kleiner);                              v.animate(liste, "CONCAT", "Anhängen der Liste mit den kleineren Elementen");
            liste.append(pivot);                                v.animate(liste, "APPEND", "Hinzufügen des Pivot-Elements");
            liste.concat(groesser);                             v.animate(liste, "CONCAT", "Anhängen der Liste mit den größeren Elementen");            
        }
    }
    
    
    
}
